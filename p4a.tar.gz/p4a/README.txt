To use the web and file fetchers, run these commands:

./file_tester pagea
./web_tester index.txt
